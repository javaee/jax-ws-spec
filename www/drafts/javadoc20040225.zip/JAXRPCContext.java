interface JAXRPCContext {
    void setProperty(String name, Object value);
    void removeProperty(String name);
    Object getProperty(String name);
    java.util.Iterator getPropertyNames();
    //...
}
