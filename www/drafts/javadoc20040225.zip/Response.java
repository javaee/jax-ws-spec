/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package javax.xml.rpc;

/** The <code>javax.xml.rpc.Response</code> interface provides a wrapper for
 *  responses from <code>Dispatch.invoke</code> methods. It is used to group
 *  together the response object with the corresponding context.
 *
 *  @version 1.0
 *  @author  Marc Hadley
**/

interface Response<T> {

    /** Gets the contained response.
     *
     * @return The contained response.
     *
     * @throws JAXRPCException If any fault occured during operation 
     * invocation.
     * Typically this will only happen when a <code>Response<code> instance is
     * used in an <code>AsyncHandler.handleResult</code> implementation.
     * Synchronous <code>Dispatch.invoke</code> methods throw exceptions
     * directly.
    **/
    T get();

    /** Gets the contained response context.
     *
     * @return The contained response context. May be <code>null</code> if a
     * response was not processed.
     *
    **/
    JAXRPCContext getContext();
}
