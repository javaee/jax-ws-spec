/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package javax.xml.rpc;

/** The <code>javax.xml.rpc.AsyncHandler</code> interface is implemented by
 * clients that wish to receive callback notification of the completion of
 * service endpoint operations invoked using <code>Dispatch.invokeAsync</code>.
 *
 *  @version 1.0
 *  @author  Marc Hadley
**/

interface AsyncHandler<T> {

    /** Called when the results on an operation invoked using
     * <code>Dispatch.invokeAsync</code> are available.
     *
     * @param res The results of the operation invocation.
     *
    **/
    void handleResponse(Response<T> res);
}