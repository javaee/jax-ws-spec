/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package javax.xml.rpc;

import java.net.URI;
import javax.xml.bin.JAXBContext;
import javax.xml.transform.Source;
import java.rmi.RemoteException;

/** The <code>javax.xml.rpc.Dispatch</code> interface provides support 
 *  for the dynamic invocation of a service endpoint operation using XML
 *  constructs. The <code>javax.xml.rpc.Service</code> interface acts as a 
 *  factory for the creation of <code>Dispatch</code> instances.
 *
 *  @version 1.0
 *  @author  Marc Hadley
**/

public interface Dispatch {

    /** Obtains a new <code>Dispatch</code> instance with the same binding and
     *  endpoint address as the current instance.
     *
     * @return The new <code>Dispatch</code> instance.
     *
    **/
    Dispatch clone();
    
    /** Sets the protocol binding to be used.
     *
     * @param b The protocol binding. Protocol binding instances are obtained
     * via a <code>Service</code> instance.
     *
     * @throws javax.xml.rpc.JAXRPCException If the requested binding is not
     * supported.
     *
    **/
    void setProtocolBinding(ProtocolBinding b);

    /** Gets the protocol binding in use.
     *
     * @return The currently configured protocol binding. Returns 
     * <code>null</code> if not bound to a protocol.
     *
    **/
    ProtocolBinding getProtocolBinding();

    /** Indicates whether the instance is bound to a protocol. Equivalent to
     * <code>(getProtocolBinding()==null ? false : true)</code>.
     *
     * @return Returns <code>true</code> if the instance is bound,
     * <code>false</code> otherwise.
     *
    **/
    boolean isBound();

    /** Sets the endpoint address of the service to be invoked.
     *
     * @param address The endpoint address specified as a protocol binding 
     * specific string.
     *
    **/
    void setTargetEndpointAddress(String address);

    /** Gets the endpoint address of the service to be invoked.
     *
     * @return The endpoint address specified as a protocol binding specific
     *     string.
     *
    **/
    String getTargetEndpointAddress();

    /** Create a <code>JAXRPCContext</code> instance for use in subsequent
     * <code>invoke</code> and <code>invokeAsync</code> operations.
     *
     * A <code>JAXRPCContext</code> is used to pass information between
     * client code and protocol handlers to make use of binding specific
     * functionality, e.g. to include SOAP headers or attachments.
     *
     * @return A new <code>JAXRPCContext</code> instance.
     *
     * @see javax.xml.rpc.JAXRPCContext for more information on context.
    **/
    JAXRPCContext createJAXRPCContext();

    /** Invoke a service operation synchronously using an XML fragment.
     * 
     * The client is responsible for ensuring that the XML fragment is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg An XML fragment that will form the payload of
     *     the message used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @return A <code>Response</code> wrapper for the XML fragment that formed
     *     the payload of the response to the operation invocation.
     * @throws RemoteException If a fault occurs during communication with
     *     the service
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    Response<Source> invoke(Source msg, JAXRPCContext jc)
        throws RemoteException;
        
    
    /** Invoke a service operation asynchronously using an XML fragment.
     * The method returns without waiting for the response to the operation 
     * invocation, the response to the operation is obtained using method on the
     * returned <code>AsyncResponse</code> instance.
     * 
     * The client is responsible for ensuring that the XML fragment is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg An XML fragment that will form the payload of the message
     *     used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @return A response object that may be used to check the status of the
     *     request and obtain the XML fragment that forms the payload of the
     *     response to the operation invocation.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    AsyncResponse<Source> invokeAsync(Source msg,
        JAXRPCContext jc);

    /** Invoke a service operation asynchronously using an XML fragment. The
     *  method returns without waiting for the response to the operation
     *  invocation, the results of the operation are communicated to the client
     *  via the handler.
     * 
     * The client is responsible for ensuring that the XML fragment is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg An XML fragment that will form the payload of the message
     *     used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @param handler The handler object that will receive an
     *     XML fragment that formed the payload of the
     *     response to the operation invocation.
     * @return A response object that may be used to check the status of the
     *     request. This object must not be used to try to obtain the results
     *     of the operation - the object returned from the <code>get</code>
     *     method of <code>AsyncResponse<?></code> is implementation dependent
     *     and any use of it will result in non-portable behaviour.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    AsyncResponse<?> invokeAsync(Source msg,
        JAXRPCContext jc, AsyncHandler<Source> handler);
               
    /** Invoke a service operation synchronously using a JAXB object.
     * 
     * The client is responsible for ensuring that the
     * result of marshalling the JAXB object is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg A JAXB object that, when marshalled, will form the payload of
     *     the message used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @return A <code>Response</code> wrapper for the JAXB object unmarshalled
     *     from the payload of the response to the operation invocation.
     * @throws RemoteException If a fault occurs during communication with
     *     the service
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    Response<Object> invoke(Object msg, JAXBContext c, JAXRPCContext jc)
        throws java.rmi.RemoteException;

    /** Invoke a service operation asynchronously using a JAXB object.
     * The operation returns without waiting for the response to the operation 
     * invocation, the response to the operation is obtained using methods on
     * the returned <code>AsyncResponse</code> instance.
     * 
     * The client is responsible for ensuring that the result
     * of marshalling the JAXB object is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg A JAXB object that, when marshalled, will form the payload
     *     of the message used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @return A response object that may be used to check the status of the
     *     request and obtain the JAXB object unmarshalled from the
     *     payload of the response to the operation invocation.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    AsyncResponse<Object> invokeAsync(Object msg, JAXBContext c,
        JAXRPCContext jc);

    /** Invoke a service operation asynchronously using a JAXB object. The
     *  method returns without waiting for the response to the operation
     *  invocation, the results of the operation are communicated to the client
     *  via the handler.
     * 
     * The client is responsible for ensuring that the result of marshalling       
     * the JAXB object is
     * formed according to the requirements of the protocol binding in use.
     *
     * @param msg A JAXB object that, when marshalled, will form the payload of
     *     the message used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @param handler The handler object that will receive the
     *     JAXB object unmarshalled from the payload of the
     *     response to the operation invocation.
     * @return A response object that may be used to check the status of the
     *     request. This object must not be used to try to obtain the results
     *     of the operation - the object returned from the <code>get</code>
     *     method of <code>AsyncResponse<?></code> is implementation dependent
     *     and any use of it will result in non-portable behaviour.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance
    **/
    AsyncResponse<?> invokeAsync(Object msg,
        JAXRPCContext jc, AsyncHandler<Object> h);
           
    /** Invokes a service operation with an XML fragment using the one-way
     *  interaction mode. The operation invocation is logically non-blocking,
     *  subject to the capabilities of the underlying protocol, no results
     *  are returned. When
     *  the protocol in use is SOAP/HTTP, this method must block until
     *  an HTTP response code has been received or an error occurs.
     *
     * @param msg An XML fragment that will form the payload of the message
     *     used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance or if an error occurs during the
     *     invocation.
    **/
    void invokeOneWay(org.w3c.dom.Element msg, JAXRPCContext jc);
    
    /** Invokes a service operation with a JAXB object using the one-way
     *  interaction mode. The operation invocation is logically non-blocking,
     *  subject to the capabilities of the underlying protocol, no results
     *  are returned. When
     *  the protocol in use is SOAP/HTTP, this method must block until
     *  an HTTP response code has been received or an error occurs.
     *
     * @param msg A JAXB object that, when marshalled, will form the payload of
     *     the message used to invoke the operation.
     * @param jc Context information pretaining to the operation invocation.
     * @throws JAXRPCException If there is any error in the configuration of
     *     the <code>Dispatch</code> instance or if an error occurs during the
     *     invocation.
    **/
    void invokeOneWay(javax.xml.bind.Element msg, JAXBContext c,
        JAXRPCContext jc);
}
